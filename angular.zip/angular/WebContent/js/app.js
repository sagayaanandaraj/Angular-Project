var myApp=angular.module("myApp",[]);

myApp.controller("myController",function ($scope) {
	console.log("In my controller..");

	$scope.newUser = {};
	$scope.ClickedUser = {};

	$scope.users = [
       {ProductName:"Laptop",ProductCategory:"acer",Productprice:"68,000/-"},
       {ProductName:"Keyboard",ProductCategory:"Leo",Productprice:"8,000/-"},
       {ProductName:"Mouse",ProductCategory:"hp",Productprice:"6,800/-"}

	];

	$scope.saveProduct = function(){
      //console.log($scope.newUser);
        $scope.users.push($scope.newUser);
        $scope.newUser = {};
	};

	$scope.selectUser = function(user) {
		console.log(user);
		$scope.clickedUser = user;
	};

	$scope.updateUser = function(){

	};

	$scope.deleteUser = function(){
		$scope.users.splice($scope.users.indexOf($scope.clickedUser),1);
	};
});