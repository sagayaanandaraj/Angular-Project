var myApp=angular.module("myApp",[]);

myApp.controller("myController",function ($scope) {
	console.log("In my controller..");

	$scope.newUser = {};
	$scope.ClickedUser = {};

	$scope.users = [
       {ProductName:"Gowthaman",ProductCategory:"Asst Prof",Productprice:"25,000/-"},
       {ProductName:"Azar",ProductCategory:"Prof",Productprice:"28,000/-"},
       {ProductName:"Raja",ProductCategory:"Asst Prof",Productprice:"18,800/-"}

	];

	$scope.saveProduct = function(){
      //console.log($scope.newUser);
        $scope.users.push($scope.newUser);
        $scope.newUser = {};
	};

	$scope.selectUser = function(user) {
		console.log(user);
		$scope.clickedUser = user;
	};

	$scope.updateUser = function(){

	};

	$scope.deleteUser = function(){
		$scope.users.splice($scope.users.indexOf($scope.clickedUser),1);
	};
});